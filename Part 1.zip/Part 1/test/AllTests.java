package part.pkg1;

import org.junit.Test;
import static org.junit.Assert.*;

public class AllTests {
    
    @Test
    public void testUsernameValidation() {
        System.out.println("Testing username validation...");
        assertTrue("Valid username with underscore", UserCredentials.validateUsername("user_"));
        assertTrue("Valid username with underscore", UserCredentials.validateUsername("a_b"));
        assertFalse("Username too long", UserCredentials.validateUsername("username"));
        assertFalse("Username without underscore", UserCredentials.validateUsername("user"));
    }
    
    @Test
    public void testPasswordValidation() {
        System.out.println("Testing password validation...");
        assertTrue("Valid password", UserCredentials.validatePassword("Passw0rd!"));
        assertTrue("Valid password", UserCredentials.validatePassword("A1@bcdefg"));
        assertFalse("Password too short", UserCredentials.validatePassword("short"));
        assertFalse("No uppercase letter", UserCredentials.validatePassword("nouppercase1!"));
    }
    
    @Test
    public void testCellphoneValidation() {
        System.out.println("Testing cellphone validation...");
        assertTrue("Valid cellphone", UserCredentials.validateCellphone("+1234567890"));
        assertTrue("Valid cellphone", UserCredentials.validateCellphone("+1123"));
        assertFalse("No country code", UserCredentials.validateCellphone("1234567890"));
        assertFalse("Contains letters", UserCredentials.validateCellphone("+abc123"));
    }
    
    @Test
    public void testUserCredentialsObject() {
        System.out.println("Testing UserCredentials object...");
        UserCredentials user = new UserCredentials("test_", "Passw0rd!", "+1234567890");
        assertEquals("Username should match", "test_", user.getUsername());
        assertEquals("Password should match", "Passw0rd!", user.getPassword());
        assertEquals("Cellphone should match", "+1234567890", user.getCellphone());
    }
    
    @Test
    public void testLoginPanelFields() {
        System.out.println("Testing LoginPanel fields...");
        LoginPanel panel = new LoginPanel();
        panel.usernameField.setText("test_user");
        panel.passwordField.setText("testpass");
        
        assertEquals("Username should match", "test_user", panel.getUsername());
        assertEquals("Password should match", "testpass", panel.getPassword());
    }
    
    @Test
    public void testRegistrationPanelFields() {
        System.out.println("Testing RegistrationPanel fields...");
        RegistrationPanel panel = new RegistrationPanel();
        panel.usernameField.setText("test_user");
        panel.passwordField.setText("testpass");
        panel.cellphoneField.setText("+1234567890");
        
        assertEquals("Username should match", "test_user", panel.getUsername());
        assertEquals("Password should match", "testpass", panel.getPassword());
        assertEquals("Cellphone should match", "+1234567890", panel.getCellphone());
    }
}