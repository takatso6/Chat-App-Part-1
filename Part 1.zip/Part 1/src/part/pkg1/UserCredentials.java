/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_lab
 */
import java.util.regex.Pattern;

/**
 * Class to hold user credentials and validation logic.
 */
public class UserCredentials {

    private String username;
    private String password;
    private String cellphone;

    public UserCredentials(String username, String password, String cellphone) {
        this.username = username;
        this.password = password;
        this.cellphone = cellphone;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getCellphone() {
        return cellphone;
    }

    /**
     * Validates the username according to the rules:
     * - Contains an underscore
     * - No more than 5 characters long
     */
    public static boolean validateUsername(String username) {
        if (username == null) return false;
        if (username.length() > 5) {
            return false;
        }
        return username.contains("_");
    }

    /**
     * Validates the password according to the rules:
     * - At least 8 characters long
     * - Contains at least one uppercase letter
     * - Contains at least one number
     * - Contains at least one special character
     */
    public static boolean validatePassword(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        Pattern upperCasePattern = Pattern.compile("[A-Z]");
        Pattern numberPattern = Pattern.compile("[0-9]");
        Pattern specialCharPattern = Pattern.compile("[^a-zA-Z0-9]");

        if (!upperCasePattern.matcher(password).find()) {
            return false;
        }
        if (!numberPattern.matcher(password).find()) {
            return false;
        }
        if (!specialCharPattern.matcher(password).find()) {
            return false;
        }
        return true;
    }

    /**
     * Validates the cellphone number according to the rules:
     * - Starts with international country code (e.g., +1)
     * - Followed by up to 10 digits
     */
    public static boolean validateCellphone(String cellphone) {
        if (cellphone == null) return false;
        // Regex explanation:
        // ^\+\d{1,3} : starts with + followed by 1 to 3 digits (country code)
        // \d{1,10}$ : followed by 1 to 10 digits (phone number)
        String regex = "^\\+\\d{1,3}\\d{1,10}$";
        return cellphone.matches(regex);
    }
}