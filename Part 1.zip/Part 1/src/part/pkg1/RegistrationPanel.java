/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Registration panel GUI.
 */
public class RegistrationPanel extends JPanel {

    JTextField usernameField;
    JPasswordField passwordField;
    JTextField cellphoneField;
    private JButton registerButton;
    private JButton switchToLoginButton;

    public RegistrationPanel() {
        setBackground(new Color(173, 216, 230)); // Light blue
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Username:"), gbc);

        usernameField = new JTextField(15);
        gbc.gridx = 1;
        add(usernameField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Password:"), gbc);

        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        add(passwordField, gbc);

        // Cellphone
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Cellphone:"), gbc);

        cellphoneField = new JTextField(15);
        gbc.gridx = 1;
        add(cellphoneField, gbc);

        // Register button
        registerButton = new JButton("Register");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(registerButton, gbc);

        // Switch to login button
        switchToLoginButton = new JButton("Already Registered? Login");
        gbc.gridy = 4;
        add(switchToLoginButton, gbc);
    }

    // Getters for input values
    public String getUsername() {
        return usernameField.getText().trim();
    }

    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    public String getCellphone() {
        return cellphoneField.getText().trim();
    }

    // Clear input fields
    public void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        cellphoneField.setText("");
    }

    // Add action listeners
    public void addRegisterListener(ActionListener listener) {
        registerButton.addActionListener(listener);
    }

    public void addSwitchToLoginListener(ActionListener listener) {
        switchToLoginButton.addActionListener(listener);
    }
}
