/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;

/**
 * Main application JFrame that manages login and registration panels.
 */
public class MainApp extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;

    private RegistrationPanel registrationPanel;
    private LoginPanel loginPanel;

    // Store registered user credentials in memory
    UserCredentials registeredUser = null;

    public MainApp() {
        setTitle("Login and Registration");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        registrationPanel = new RegistrationPanel();
        loginPanel = new LoginPanel();

        mainPanel.add(registrationPanel, "registration");
        mainPanel.add(loginPanel, "login");

        add(mainPanel);

        // Show registration panel by default
        cardLayout.show(mainPanel, "registration");

        // Add listeners for registration panel
        registrationPanel.addRegisterListener(e -> handleRegistration());
        registrationPanel.addSwitchToLoginListener(e -> {
            loginPanel.clearFields();
            cardLayout.show(mainPanel, "login");
        });

        // Add listeners for login panel
        loginPanel.addLoginListener(e -> handleLogin());
        loginPanel.addSwitchToRegisterListener(e -> {
            registrationPanel.clearFields();
            cardLayout.show(mainPanel, "registration");
        });
    }

    /**
     * Handles registration logic with validation and feedback.
     */
    private void handleRegistration() {
        String username = registrationPanel.getUsername();
        String password = registrationPanel.getPassword();
        String cellphone = registrationPanel.getCellphone();

        // Validate username
        if (!UserCredentials.validateUsername(username)) {
            JOptionPane.showMessageDialog(this,
                    "Username must contain an underscore and be no more than 5 characters long.",
                    "Invalid Username",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate password
        if (!UserCredentials.validatePassword(password)) {
            JOptionPane.showMessageDialog(this,
                    "Password must be at least 8 characters long, contain a capital letter, a number, and a special character.",
                    "Invalid Password",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate cellphone
        if (!UserCredentials.validateCellphone(cellphone)) {
            JOptionPane.showMessageDialog(this,
                    "Cellphone must start with international country code (e.g., +1) followed by up to 10 digits.",
                    "Invalid Cellphone",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Save registered user info
        registeredUser = new UserCredentials(username, password, cellphone);

        JOptionPane.showMessageDialog(this,
                "Registration successful!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);

        registrationPanel.clearFields();
        loginPanel.clearFields();

        // Switch to login panel
        cardLayout.show(mainPanel, "login");
    }

    /**
     * Handles login logic with validation and feedback.
     */
    private void handleLogin() {
        if (registeredUser == null) {
            JOptionPane.showMessageDialog(this,
                    "No registered user found. Please register first.",
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String username = loginPanel.getUsername();
        String password = loginPanel.getPassword();

        if (username.equals(registeredUser.getUsername()) && password.equals(registeredUser.getPassword())) {
            JOptionPane.showMessageDialog(this,
                    "Login successful!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            loginPanel.clearFields();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Incorrect username or password.",
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainApp app = new MainApp();
            app.setVisible(true);
        });
    }
}
