/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg1;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Login panel GUI.
 */
public class LoginPanel extends JPanel {

    JTextField usernameField;
    JPasswordField passwordField;
    private JButton loginButton;
    private JButton switchToRegisterButton;

    public LoginPanel() {
        setBackground(new Color(173, 216, 230)); // Light blue
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Username:"), gbc);

        usernameField = new JTextField(15);
        gbc.gridx = 1;
        add(usernameField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Password:"), gbc);

        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        add(passwordField, gbc);

        // Login button
        loginButton = new JButton("Login");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(loginButton, gbc);

        // Switch to register button
        switchToRegisterButton = new JButton("Not Registered? Register");
        gbc.gridy = 3;
        add(switchToRegisterButton, gbc);
    }

    // Getters for input values
    public String getUsername() {
        return usernameField.getText().trim();
    }

    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    // Clear input fields
    public void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
    }

    // Add action listeners
    public void addLoginListener(ActionListener listener) {
        loginButton.addActionListener(listener);
    }

    public void addSwitchToRegisterListener(ActionListener listener) {
        switchToRegisterButton.addActionListener(listener);
    }
}